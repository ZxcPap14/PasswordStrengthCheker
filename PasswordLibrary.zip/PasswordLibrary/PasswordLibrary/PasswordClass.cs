﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PasswordLibrary
{
    public class PasswordClass
    {
        /// <summary>
        /// В качестве параметра передается строка - пароль
        /// </summary>
        /// <param name="password"></param>
        /// <returns>
        /// Метод возвращает целое число, соответствующее сложности пароля
        /// </returns>
        public static int PasswordStrengthCheker(string password)
        {
            int pas= 0;
            if (string.IsNullOrEmpty(password))
            {
                return 0;
            }
            if (password.Length>7)
            {
                pas++;
            }
            if (Regex.Match(password, "[0-9]").Success)
            {
                pas++;
            }
            if (Regex.Match(password, "[a-z]").Success)
            {
                pas++ ;
            }
            if (Regex.Match(password, "[A-Z]").Success)
            {
                pas++;
            }
            if(Regex.Match(password, "[\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)\\{\\}\\[\\]\\;\\;\\'\\/\\?\\, \\.\\-\\+]").Success)
            { 
                pas++; 
            }
            if (Regex.Match(password, "[а-яА-яëЕ]").Success)
            {
                throw new Exception("Пароль не может содержать кириллические символы"); 
            }

            return pas;

        }
    }
}
